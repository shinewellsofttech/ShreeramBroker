import React from 'react';
 

const Header = () => {
   return (
       <div style={{width: 1440, height: 1117, position: 'relative', background: 'white', overflow: 'hidden'}}>
 <div style={{width: 1440, height: 923, left: 0, top: 0, position: 'absolute', overflow: 'hidden'}}>
   <div style={{width: 1440, height: 807, left: 0, top: 0, position: 'absolute', overflow: 'hidden'}}>
     <div style={{width: 1440, height: 748, left: 0, top: 0, position: 'absolute'}}>
       <div style={{width: 604.15, height: 700, left: 835.86, top: 0, position: 'absolute', background: '#184C99'}} />
       <div style={{width: 111.61, height: 176.96, left: 0, top: 0, position: 'absolute', background: '#184C99'}} />
     </div>
     <div style={{width: 625, height: 721.15, left: 780, top: 86, position: 'absolute', overflow: 'hidden'}}>
       <div style={{width: 204.69, height: 234.58, left: 355.34, top: 148.13, position: 'absolute', background: '#FF6551'}} />
       <div style={{width: 488, height: 452.45, left: 41.64, top: 180.22, position: 'absolute', background: '#273D5E'}} />
       <div style={{width: 242.35, height: 251.83, left: 0, top: 418.65, position: 'absolute', background: '#8EC2F2'}} />
       <div style={{width: 110.57, height: 117.13, left: 86.74, top: 172.37, position: 'absolute', background: 'white'}} />
       <div style={{width: 125.85, height: 178.99, left: 72.11, top: 428.39, position: 'absolute', background: 'white'}} />
       <div style={{width: 279.12, height: 274.64, left: 211.98, top: 189.95, position: 'absolute', background: 'white'}} />
       <div style={{width: 50.50, height: 222.59, left: 504.67, top: 373.97, position: 'absolute', background: 'white'}} />
       <div style={{width: 115.69, height: 274.79, left: 0.17, top: 166.87, position: 'absolute', background: 'white'}} />
       <img style={{width: 653.15, height: 763.15, left: -10.18, top: -42, position: 'absolute'}} src="https://placehold.co/653x763" />
       <div style={{width: 162.87, height: 145.72, left: 350.67, top: 487.67, position: 'absolute', background: '#F3CD03'}} />
     </div>
   </div>
   <div style={{width: 1440, height: 923, left: 0, top: 0, position: 'absolute'}} />
 </div>
 <div style={{width: 1322, height: 91, left: 59, top: 0, position: 'absolute', overflow: 'hidden'}}>
   <div style={{width: 1322, height: 91, left: 0, top: 0, position: 'absolute', overflow: 'hidden'}}>
     <div style={{width: 187, height: 58, left: 136, top: 17, position: 'absolute', overflow: 'hidden'}}>
       <div style={{left: 0, top: 13, position: 'absolute', color: '#252B42', fontSize: 24, fontFamily: 'Montserrat', fontWeight: '700', lineHeight: 32, letterSpacing: 0.10, wordWrap: 'break-word'}}>Brandname</div>
     </div>
     <div style={{width: 24, height: 13.71, left: 1298, top: 39, position: 'absolute', overflow: 'hidden'}}>
       <div style={{width: 24, height: 13.71, left: 0, top: 0, position: 'absolute'}} />
     </div>
     <div style={{width: 815, height: 58, left: 364, top: 16, position: 'absolute', overflow: 'hidden'}}>
       <div style={{left: 0, top: 17, position: 'absolute', overflow: 'hidden', justifyContent: 'flex-start', alignItems: 'center', gap: 21, display: 'inline-flex'}}>
         <div style={{width: 43, height: 24, position: 'relative', overflow: 'hidden'}}>
           <div style={{width: 43, height: 24, left: 0, top: 0, position: 'absolute', overflow: 'hidden'}}>
             <div style={{left: 0, top: 0, position: 'absolute', textAlign: 'center', color: '#737373', fontSize: 14, fontFamily: 'Montserrat', fontWeight: '700', lineHeight: 24, letterSpacing: 0.20, wordWrap: 'break-word'}}>Home</div>
           </div>
         </div>
         <div style={{width: 59, height: 24, position: 'relative', overflow: 'hidden'}}>
           <div style={{width: 59, height: 24, left: 0, top: 0, position: 'absolute', overflow: 'hidden'}}>
             <div style={{left: 0, top: 0, position: 'absolute', textAlign: 'center', color: '#737373', fontSize: 14, fontFamily: 'Montserrat', fontWeight: '700', lineHeight: 24, letterSpacing: 0.20, wordWrap: 'break-word'}}>Product</div>
           </div>
         </div>
         <div style={{width: 52, height: 24, position: 'relative', overflow: 'hidden'}}>
           <div style={{width: 52, height: 24, left: 0, top: 0, position: 'absolute', overflow: 'hidden'}}>
             <div style={{left: 0, top: 0, position: 'absolute', textAlign: 'center', color: '#737373', fontSize: 14, fontFamily: 'Montserrat', fontWeight: '700', lineHeight: 24, letterSpacing: 0.20, wordWrap: 'break-word'}}>Pricing</div>
           </div>
         </div>
         <div style={{width: 58, height: 24, position: 'relative', overflow: 'hidden'}}>
           <div style={{width: 58, height: 24, left: 0, top: 0, position: 'absolute', overflow: 'hidden'}}>
             <div style={{left: 0, top: 0, position: 'absolute', textAlign: 'center', color: '#737373', fontSize: 14, fontFamily: 'Montserrat', fontWeight: '700', lineHeight: 24, letterSpacing: 0.20, wordWrap: 'break-word'}}>Contact</div>
           </div>
         </div>
       </div>
       <div style={{left: 515, top: 3, position: 'absolute', justifyContent: 'flex-start', alignItems: 'center', gap: 45, display: 'inline-flex'}}>
         <div style={{width: 41, height: 22, position: 'relative', overflow: 'hidden'}}>
           <div style={{width: 41, height: 22, left: 0, top: 0, position: 'absolute', overflow: 'hidden'}}>
             <div style={{left: 0, top: 0, position: 'absolute', textAlign: 'right', color: '#FF6551', fontSize: 14, fontFamily: 'Montserrat', fontWeight: '700', lineHeight: 22, letterSpacing: 0.20, wordWrap: 'break-word'}}>Login</div>
           </div>
         </div>
         <div style={{width: 214, height: 52, position: 'relative', overflow: 'hidden'}}>
           <div style={{paddingLeft: 25, paddingRight: 25, paddingTop: 15, paddingBottom: 15, left: 0, top: 0, position: 'absolute', background: '#FF6551', overflow: 'hidden', borderRadius: 5, justifyContent: 'flex-start', alignItems: 'center', gap: 15, display: 'inline-flex'}}>
             <div style={{color: 'white', fontSize: 14, fontFamily: 'Montserrat', fontWeight: '700', lineHeight: 22, letterSpacing: 0.20, wordWrap: 'break-word'}}>JOIN US</div>
             <div style={{width: 12, height: 10, position: 'relative', overflow: 'hidden'}}>
               <div style={{width: 12, height: 10, left: 0, top: 0, position: 'absolute', background: 'white'}} />
             </div>
           </div>
         </div>
       </div>
     </div>
   </div>
 </div>
 <div style={{width: 1046, paddingTop: 80, paddingBottom: 80, left: 197, top: 104, position: 'absolute', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 80, display: 'inline-flex'}}>
   <div style={{overflow: 'hidden', justifyContent: 'flex-start', alignItems: 'center', gap: 30, display: 'inline-flex'}}>
     <div style={{width: 599, overflow: 'hidden', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 35, display: 'inline-flex'}}>
       <div style={{color: '#FF6551', fontSize: 16, fontFamily: 'Montserrat', fontWeight: '700', lineHeight: 24, letterSpacing: 0.10, wordWrap: 'break-word'}}>For Better Future</div>
       <div style={{width: 542, color: '#252B42', fontSize: 58, fontFamily: 'Montserrat', fontWeight: '700', lineHeight: 80, letterSpacing: 0.20, wordWrap: 'break-word'}}>HIGH QUALITY COURSES </div>
       <div style={{width: 338, color: '#737373', fontSize: 20, fontFamily: 'Montserrat', fontWeight: '400', lineHeight: 30, letterSpacing: 0.20, wordWrap: 'break-word'}}>Every day brings with it a fresh set of learning possibilities.</div>
       <div style={{justifyContent: 'flex-start', alignItems: 'flex-start', gap: 10, display: 'inline-flex'}}>
         <div style={{paddingLeft: 40, paddingRight: 40, paddingTop: 15, paddingBottom: 15, background: '#FF6551', overflow: 'hidden', borderRadius: 5, flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'center', gap: 10, display: 'inline-flex'}}>
           <div style={{textAlign: 'center', color: 'white', fontSize: 14, fontFamily: 'Montserrat', fontWeight: '700', lineHeight: 22, letterSpacing: 0.20, wordWrap: 'break-word'}}>Get Quote Now</div>
         </div>
         <div style={{paddingLeft: 40, paddingRight: 40, paddingTop: 15, paddingBottom: 15, overflow: 'hidden', borderRadius: 5, outline: '1px #FF6551 solid', outlineOffset: '-1px', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'center', gap: 10, display: 'inline-flex'}}>
           <div style={{textAlign: 'center', color: '#FF6551', fontSize: 14, fontFamily: 'Montserrat', fontWeight: '700', lineHeight: 22, letterSpacing: 0.20, wordWrap: 'break-word'}}>Learn More</div>
         </div>
       </div>
     </div>
     <div style={{width: 415, height: 280}} />
   </div>
   <div style={{justifyContent: 'flex-start', alignItems: 'center', gap: 30, display: 'inline-flex'}}>
     <div style={{width: 328, flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', display: 'inline-flex'}}>
       <div style={{width: 328, paddingLeft: 40, paddingRight: 40, paddingTop: 35, paddingBottom: 35, background: 'white', boxShadow: '0px 13px 19px rgba(0, 0, 0, 0.07)', overflow: 'hidden', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 20, display: 'flex'}}>
         <div style={{paddingLeft: 19, paddingRight: 19, paddingTop: 22, paddingBottom: 22, background: '#FF6551', overflow: 'hidden', borderRadius: 10, flexDirection: 'column', justifyContent: 'center', alignItems: 'center', gap: 10, display: 'flex'}}>
           <div style={{width: 32, height: 32, position: 'relative', overflow: 'hidden'}}>
             <div style={{width: 32, height: 32, left: 0, top: 0, position: 'absolute', overflow: 'hidden'}}>
               <div style={{width: 28.57, height: 18.29, left: 1.71, top: 2.29, position: 'absolute', background: 'white'}} />
               <div style={{width: 32, height: 1.14, left: 0, top: 0, position: 'absolute', background: 'white'}} />
               <div style={{width: 12.57, height: 10.29, left: 9.71, top: 21.71, position: 'absolute', background: 'white'}} />
             </div>
           </div>
         </div>
         <div style={{width: 222, color: '#252B42', fontSize: 24, fontFamily: 'Montserrat', fontWeight: '700', lineHeight: 32, letterSpacing: 0.10, wordWrap: 'break-word'}}>Expert instruction</div>
         <div style={{width: 50, height: 2, background: '#E74040'}} />
         <div style={{color: '#737373', fontSize: 14, fontFamily: 'Montserrat', fontWeight: '400', lineHeight: 20, letterSpacing: 0.20, wordWrap: 'break-word'}}>The gradual accumulation of <br/>information about atomic and <br/>small-scale behaviour...</div>
       </div>
     </div>
     <div style={{width: 329, flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', display: 'inline-flex'}}>
       <div style={{width: 328, paddingLeft: 40, paddingRight: 40, paddingTop: 35, paddingBottom: 35, background: 'white', boxShadow: '0px 13px 19px rgba(0, 0, 0, 0.07)', overflow: 'hidden', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 20, display: 'flex'}}>
         <div style={{paddingLeft: 19, paddingRight: 19, paddingTop: 22, paddingBottom: 22, background: '#2435A1', overflow: 'hidden', borderRadius: 10, flexDirection: 'column', justifyContent: 'center', alignItems: 'center', gap: 10, display: 'flex'}}>
           <div style={{width: 32, height: 32, position: 'relative', overflow: 'hidden'}}>
             <div style={{width: 32, height: 32, left: 0, top: 0, position: 'absolute', overflow: 'hidden'}}>
               <div style={{width: 18.38, height: 13.87, left: 3.94, top: 2.58, position: 'absolute', background: 'white'}} />
               <div style={{width: 5.47, height: 8.35, left: 1.15, top: 0, position: 'absolute', background: 'white'}} />
               <div style={{width: 4.46, height: 3.22, left: 26.49, top: 16.90, position: 'absolute', background: 'white'}} />
               <div style={{width: 5.58, height: 5.17, left: 21.06, top: 13.11, position: 'absolute', background: 'white'}} />
               <div style={{width: 17.99, height: 18.99, left: 6.35, top: 13.01, position: 'absolute', background: 'white'}} />
             </div>
           </div>
         </div>
         <div style={{width: 259, color: '#252B42', fontSize: 24, fontFamily: 'Montserrat', fontWeight: '700', lineHeight: 32, letterSpacing: 0.10, wordWrap: 'break-word'}}>Training Courses</div>
         <div style={{width: 50, height: 2, background: '#E74040'}} />
         <div style={{color: '#737373', fontSize: 14, fontFamily: 'Montserrat', fontWeight: '400', lineHeight: 20, letterSpacing: 0.20, wordWrap: 'break-word'}}>The gradual accumulation of <br/>information about atomic and <br/>small-scale behaviour...</div>
       </div>
     </div>
     <div style={{width: 329, flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', display: 'inline-flex'}}>
       <div style={{width: 328, paddingLeft: 40, paddingRight: 40, paddingTop: 35, paddingBottom: 35, background: 'white', boxShadow: '0px 13px 19px rgba(0, 0, 0, 0.07)', overflow: 'hidden', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 20, display: 'flex'}}>
         <div style={{paddingLeft: 19, paddingRight: 19, paddingTop: 22, paddingBottom: 22, background: '#FFC652', overflow: 'hidden', borderRadius: 10, flexDirection: 'column', justifyContent: 'center', alignItems: 'center', gap: 10, display: 'flex'}}>
           <div style={{width: 32, height: 32, position: 'relative', overflow: 'hidden'}}>
             <div style={{width: 32, height: 32, left: 0, top: 0, position: 'absolute', overflow: 'hidden'}}>
               <div style={{width: 32, height: 27.34, left: 0, top: 2.33, position: 'absolute', overflow: 'hidden'}}>
                 <div style={{width: 32, height: 27.34, left: 0, top: 0, position: 'absolute', overflow: 'hidden'}}>
                   <div style={{width: 32, height: 27.34, left: 0, top: 0, position: 'absolute', background: 'white'}} />
                 </div>
               </div>
               <div style={{width: 16.88, height: 7.14, left: 7.56, top: 13.80, position: 'absolute', overflow: 'hidden'}}>
                 <div style={{width: 16.88, height: 7.14, left: 0, top: 0, position: 'absolute', overflow: 'hidden'}}>
                   <div style={{width: 16.88, height: 7.14, left: 0, top: 0, position: 'absolute', background: 'white'}} />
                 </div>
               </div>
             </div>
           </div>
         </div>
         <div style={{width: 239, color: '#252B42', fontSize: 24, fontFamily: 'Montserrat', fontWeight: '700', lineHeight: 32, letterSpacing: 0.10, wordWrap: 'break-word'}}>Lifetime access</div>
         <div style={{width: 50, height: 2, background: '#E74040'}} />
         <div style={{color: '#737373', fontSize: 14, fontFamily: 'Montserrat', fontWeight: '400', lineHeight: 20, letterSpacing: 0.20, wordWrap: 'break-word'}}>The gradual accumulation of <br/>information about atomic and <br/>small-scale behaviour...</div>
       </div>
     </div>
   </div>
 </div>
</div>
   )
}


export default Header;