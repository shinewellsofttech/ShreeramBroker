import React, { useState, useEffect, useMemo } from "react";
import {
  Row,
  Col,
  Card,
  CardBody,
  CardHeader,
  Button,
  Input,
  Badge,
  Pagination,
  PaginationItem,
  PaginationLink,
  Alert,
  Spinner,
  Container
} from "reactstrap";
import {
  useTable,
  usePagination,
  useGlobalFilter,
  useSortBy,
} from "react-table";
import { API_WEB_URLS } from "../../constants/constAPI";
import { useDispatch } from "react-redux";
import { Fn_FillListData, Fn_DeleteData } from "../../store/Functions";
import { useNavigate } from "react-router-dom";

const PageList_UnitMaster = () => {
  const [gridData, setGridData] = useState([]);
  const [loading, setLoading] = useState(true);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const rtPage_Add = "/AddUnit";
  const rtPage_Edit = "/EditUnit";
  const API_URL = API_WEB_URLS.MASTER + "/0/token/UnitMaster";

  const [state, setState] = useState({
    id: 0,
    FillArray: [],
    formData: {},
    OtherDataScore: [],
    isProgress: true,
  });

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      await Fn_FillListData(dispatch, setGridData, "gridData", API_URL + "/Id/0");
      setLoading(false);
    };

    fetchData();
  }, [dispatch, API_URL]);

  const btnAddOnClick = () => {
    navigate(rtPage_Add, { state: { Id: 0 } });
  };

  const btnEditOnClick = (Id) => {
    navigate(rtPage_Edit, { state: { Id } });
  };

  const btnDeleteOnClick = (Id) => {
    Fn_DeleteData(dispatch, setState, Id, `${API_URL}`, true)
  };

  const data = useMemo(() => gridData || [], [gridData]);

  const columns = useMemo(
    () => [
      {
        Header: "Sr No",
        accessor: (row, i) => i + 1,
        disableSortBy: true,
        Cell: ({ value }) => (
          <div className="d-flex align-items-center">
            <div className="avatar-sm bg-primary bg-opacity-10 rounded-circle d-flex align-items-center justify-content-center me-3">
              <span className="text-primary fw-semibold">{value}</span>
            </div>
          </div>
        ),
      },
      {
        Header: "Code",
        accessor: "Code",
        Cell: ({ value }) => (
          <div className="d-flex align-items-center">
            <div className="avatar-sm bg-info bg-opacity-10 rounded-circle d-flex align-items-center justify-content-center me-3">
              <i className="fas fa-hashtag text-info"></i>
            </div>
            <div>
              <h6 className="mb-0 fw-semibold text-dark">{value}</h6>
              <small className="text-muted">Unit Code</small>
            </div>
          </div>
        ),
      },
      {
        Header: "Name",
        accessor: "Name",
        Cell: ({ value }) => (
          <div className="d-flex align-items-center">
            <div className="avatar-sm bg-success bg-opacity-10 rounded-circle d-flex align-items-center justify-content-center me-3">
              <i className="fas fa-cube text-success"></i>
            </div>
            <div>
              <h6 className="mb-0 fw-semibold text-dark">{value}</h6>
              <small className="text-muted">Unit Name</small>
            </div>
          </div>
        ),
      },
      {
        Header: "Actions",
        accessor: "Id",
        disableSortBy: true,
        Cell: ({ value }) => (
          <div className="d-flex gap-2 justify-content-center">
            <Button
              color="primary"
              size="sm"
              onClick={() => btnEditOnClick(value)}
              className="px-3 py-1"
              style={{
                borderRadius: '6px',
                transition: 'all 0.3s ease'
              }}
            >
              <i className="fas fa-edit me-1"></i>
              Edit
            </Button>
            <Button
              color="danger"
              size="sm"
              onClick={() => btnDeleteOnClick(value)}
              className="px-3 py-1"
              style={{
                borderRadius: '6px',
                transition: 'all 0.3s ease'
              }}
            >
              <i className="fas fa-trash me-1"></i>
              Delete
            </Button>
          </div>
        ),
      },
    ],
    []
  );

  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    prepareRow,
    page,
    canPreviousPage,
    canNextPage,
    pageOptions,
    pageCount,
    gotoPage,
    nextPage,
    previousPage,
    setPageSize,
    state: { pageIndex, pageSize, globalFilter },
    setGlobalFilter,
  } = useTable(
    {
      columns,
      data,
      initialState: { pageIndex: 0, pageSize: 10 },
    },
    useGlobalFilter,
    useSortBy,
    usePagination
  );

  const renderPagination = () => {
    const paginationItems = [];
    const maxVisiblePages = 5;
    let startPage = Math.max(0, pageIndex - Math.floor(maxVisiblePages / 2));
    let endPage = Math.min(pageCount - 1, startPage + maxVisiblePages - 1);

    if (endPage - startPage + 1 < maxVisiblePages) {
      startPage = Math.max(0, endPage - maxVisiblePages + 1);
    }

    // Previous button
    paginationItems.push(
      <PaginationItem key="prev" disabled={!canPreviousPage}>
        <PaginationLink onClick={() => previousPage()} href="#">
          <i className="fas fa-chevron-left"></i>
        </PaginationLink>
      </PaginationItem>
    );

    // Page numbers
    for (let i = startPage; i <= endPage; i++) {
      paginationItems.push(
        <PaginationItem key={i} active={i === pageIndex}>
          <PaginationLink onClick={() => gotoPage(i)} href="#">
            {i + 1}
          </PaginationLink>
        </PaginationItem>
      );
    }

    // Next button
    paginationItems.push(
      <PaginationItem key="next" disabled={!canNextPage}>
        <PaginationLink onClick={() => nextPage()} href="#">
          <i className="fas fa-chevron-right"></i>
        </PaginationLink>
      </PaginationItem>
    );

    return paginationItems;
  };

  if (loading) {
    return (
      <div className="page-content">
        <div className="container-fluid">
          <div className="d-flex justify-content-center align-items-center" style={{ height: '60vh' }}>
            <div className="text-center">
              <Spinner color="primary" size="lg" className="mb-3">
                Loading...
              </Spinner>
              <p className="text-muted">Loading units...</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="page-content">
      <div className="container-fluid">
        {/* Page Header */}
        <div className="row mb-4">
          <div className="col-12">
            <div className="page-title-box d-flex align-items-center justify-content-between">
              <h4 className="mb-0 text-primary fw-semibold">
                <i className="fas fa-cube me-2"></i>
                Unit Master
              </h4>
              <div className="page-title-right">
                <ol className="breadcrumb m-0">
                  <li className="breadcrumb-item">
                    <a href="#" className="text-muted">Masters</a>
                  </li>
                  <li className="breadcrumb-item active">Unit List</li>
                </ol>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content Card */}
        <Row>
          <Col lg="12">
            <Card className="shadow-sm border-0">
              <CardHeader className="bg-primary text-white py-3">
                <div className="d-flex justify-content-between align-items-center">
                  <h5 className="mb-0 fw-semibold">
                    <i className="fas fa-list me-2"></i>
                    Unit List
                  </h5>
                  <Button
                    color="light"
                    size="sm"
                    onClick={btnAddOnClick}
                    className="fw-semibold"
                    style={{
                      borderRadius: '6px',
                      border: '1px solid rgba(255,255,255,0.3)',
                      transition: 'all 0.3s ease'
                    }}
                  >
                    <i className="fas fa-plus me-2"></i>
                    Add New Unit
                  </Button>
                </div>
              </CardHeader>
              <CardBody className="p-4">
                {/* Search Section */}
                <Row className="mb-4">
                  <Col lg="6" md="8" sm="12" className="mb-3">
                    <div className="search-box position-relative">
                      <Input
                        type="text"
                        className="form-control form-control-lg border-2"
                        placeholder="Search units..."
                        value={globalFilter || ""}
                        onChange={(e) => setGlobalFilter(e.target.value)}
                        style={{
                          borderRadius: '8px',
                          paddingLeft: '45px',
                          borderColor: '#e9ecef',
                          transition: 'all 0.3s ease'
                        }}
                      />
                      <i 
                        className="fas fa-search position-absolute"
                        style={{
                          left: '15px',
                          top: '50%',
                          transform: 'translateY(-50%)',
                          color: '#6c757d',
                          zIndex: 10
                        }}
                      ></i>
                    </div>
                  </Col>
                </Row>

                {/* Data Table */}
                {data.length === 0 ? (
                  <Alert color="info" className="text-center">
                    <i className="fas fa-info-circle me-2"></i>
                    No units available.
                  </Alert>
                ) : (
                  <>
                    <div className="table-responsive">
                      <table {...getTableProps()} className="table table-hover mb-0">
                        <thead className="table-light">
                          {headerGroups.map((headerGroup, headerGroupIndex) => (
                            <tr {...headerGroup.getHeaderGroupProps()} key={headerGroupIndex}>
                              {headerGroup.headers.map((column, columnIndex) => (
                                <th 
                                  {...column.getHeaderProps(column.getSortByToggleProps())} 
                                  key={columnIndex}
                                  className="border-0 fw-semibold text-dark"
                                  style={{ cursor: column.canSort ? 'pointer' : 'default' }}
                                >
                                  <div className="d-flex align-items-center">
                                    {column.render("Header")}
                                    {column.canSort && (
                                      <span className="ms-2">
                                        {column.isSorted ? (
                                          column.isSortedDesc ? (
                                            <i className="fas fa-sort-down text-primary"></i>
                                          ) : (
                                            <i className="fas fa-sort-up text-primary"></i>
                                          )
                                        ) : (
                                          <i className="fas fa-sort text-muted"></i>
                                        )}
                                      </span>
                                    )}
                                  </div>
                                </th>
                              ))}
                            </tr>
                          ))}
                        </thead>
                        <tbody {...getTableBodyProps()}>
                          {page.map((row, rowIndex) => {
                            prepareRow(row);
                            return (
                              <tr {...row.getRowProps()} key={rowIndex} className="align-middle">
                                {row.cells.map((cell, cellIndex) => (
                                  <td {...cell.getCellProps()} key={cellIndex} className="border-0">
                                    {cell.render("Cell")}
                                  </td>
                                ))}
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>

                    {/* Pagination and Page Size Controls */}
                    {pageCount > 1 && (
                      <div className="d-flex justify-content-between align-items-center mt-4">
                        <div className="d-flex align-items-center gap-3">
                          <div className="text-muted">
                            Showing {pageIndex * pageSize + 1} to {Math.min((pageIndex + 1) * pageSize, data.length)} of {data.length} units
                          </div>
                          <div className="d-flex align-items-center gap-2">
                            <span className="text-muted">Show:</span>
                            <select
                              value={pageSize}
                              onChange={(e) => setPageSize(Number(e.target.value))}
                              className="form-select form-select-sm"
                              style={{ width: 'auto' }}
                            >
                              {[10, 20, 30, 40, 50].map((size) => (
                                <option key={size} value={size}>
                                  {size}
                                </option>
                              ))}
                            </select>
                          </div>
                        </div>
                        <Pagination className="mb-0">
                          {renderPagination()}
                        </Pagination>
                      </div>
                    )}
                  </>
                )}
              </CardBody>
            </Card>
          </Col>
        </Row>
      </div>
    </div>
  );
};

export default PageList_UnitMaster;

