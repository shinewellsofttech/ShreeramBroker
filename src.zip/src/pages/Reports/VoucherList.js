import { API_WEB_URLS } from 'constants/constAPI';
import React, { useEffect, useMemo, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { Fn_GetReport } from 'store/Functions';
import { VoucherForm } from 'pages/Transaction/Voucher';
import { Button, Card, CardBody, Col, Container, Row, Table, Input, Modal, ModalBody, ModalFooter, ModalHeader } from 'reactstrap';

function VoucherList() {
    const dispatch = useDispatch();
    const globalDates = useSelector(state => state.GlobalDates);
    const [state, setState] = useState({
        FillArray: [],
        LedgerArray: [],
        FromDate: globalDates.fromDate,
        ToDate: globalDates.toDate,   
    });
    const [searchTerm, setSearchTerm] = useState('');
    const [editModal, setEditModal] = useState({
        isOpen: false,
        voucher: null
    });
    const [addModalOpen, setAddModalOpen] = useState(false);
    const compactCellStyle = { padding: '0.35rem 0.5rem', fontSize: '0.85rem' };

    const API_URL_Get = `${API_WEB_URLS.VoucherList}/0/token`
    
const GetVoucherData = async () => {
    try {
        const formData = new FormData();
        const fromDate = new Date(state.FromDate).toISOString().split('T')[0];
        const toDate = new Date(state.ToDate).toISOString().split('T')[0];
        formData.append("FromDate", fromDate);
        formData.append("ToDate", toDate);
        const response = await Fn_GetReport(dispatch, setState, "FillArray", API_URL_Get, { arguList: { id: 0, formData: formData } }, true);
   
    } catch (error) {
        console.log("error", error);
    }
    
}

    const handleDateChange = (field, value) => {
        setState(prev => ({
            ...prev,
            [field]: value
        }));
    }

    const getCrLedgerName = (item) => item?.LedgerMasterCrName ?? item?.CrLedgerName ?? item?.LedgerName ?? '';
    const getDrLedgerName = (item) => item?.LedgerMasterDrName ?? item?.DrLedgerName ?? '';
    const getNarration = (item) => item?.Narration ?? '';
    const getCombinedLedgerNames = (item) => `${getCrLedgerName(item)} ${getDrLedgerName(item)} ${getNarration(item)}`.trim();
    const getAmount = (item) => Number(item?.TotalAmount ?? item?.Amount ?? item?.LineAmount ?? 0);

    const filteredData = (state.FillArray ?? []).filter(item => {
        const ledgerNames = getCombinedLedgerNames(item).toLowerCase();
        return ledgerNames.includes(searchTerm.toLowerCase());
    });

    const totals = useMemo(() => {
        return filteredData.reduce((sum, item) => ({
            amount: sum.amount + getAmount(item)
        }), { amount: 0 });
    }, [filteredData]);

    const formatDate = (value) => {
        if (!value) return '';
        const date = new Date(value);
        if (Number.isNaN(date.getTime())) return '';
        return date.toLocaleDateString('en-GB');
    };

    const handleEditClick = (voucher) => {
        if (!voucher?.Id) return;
        console.log('Voucher row selected:', voucher.Id);
        setEditModal({
            isOpen: true,
            voucher
        });
    };

    const closeEditModal = () => {
        setEditModal({
            isOpen: false,
            voucher: null
        });
    };

    const handleModalSuccess = () => {
        closeEditModal();
        setAddModalOpen(false);
        GetVoucherData();
    };

    const openAddModal = () => setAddModalOpen(true);
    const closeAddModal = () => setAddModalOpen(false);

    useEffect(() => {
        GetVoucherData();
    }, [dispatch, state.FromDate, state.ToDate])
  return (
    <div >
        <div style={{height:'2rem'}}>

        </div>
        <Container fluid>
            <Row>
                <Col lg={12}>
                    <Card>
                        <CardBody>
                            <div className="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
                                <h4 className="card-title mb-0">Voucher Register</h4>
                                <div className="d-flex align-items-center gap-2 flex-wrap">
                                    <div className="d-flex align-items-center gap-1">
                                        <label className="mb-0" style={{fontSize: '0.875rem', whiteSpace: 'nowrap'}}>From:</label>
                                        <Input
                                            type="date"
                                            value={state.FromDate ? new Date(state.FromDate).toISOString().split('T')[0] : ''}
                                            onChange={(e) => handleDateChange('FromDate', e.target.value)}
                                            style={{width: '140px', fontSize: '0.875rem', padding: '0.25rem 0.5rem'}}
                                        />
                                    </div>
                                    <div className="d-flex align-items-center gap-1">
                                        <label className="mb-0" style={{fontSize: '0.875rem', whiteSpace: 'nowrap'}}>To:</label>
                                        <Input
                                            type="date"
                                            value={state.ToDate ? new Date(state.ToDate).toISOString().split('T')[0] : ''}
                                            onChange={(e) => handleDateChange('ToDate', e.target.value)}
                                            style={{width: '140px', fontSize: '0.875rem', padding: '0.25rem 0.5rem'}}
                                        />
                                    </div>
                                    <div className="d-flex align-items-center gap-2">
                                        <Input
                                            type="text"
                                            placeholder="Search Ledger..."
                                            value={searchTerm}
                                            onChange={(e) => setSearchTerm(e.target.value)}
                                            style={{width: '180px', fontSize: '0.875rem', padding: '0.25rem 0.5rem'}}
                                        />
                                        <Button color="primary" size="sm" onClick={openAddModal} title="Add Voucher">
                                            <i className="mdi mdi-plus" style={{ fontSize: '1rem' }} /> Add
                                        </Button>
                                    </div>
                                </div>
                            </div>
                            <div 
                                className="table-responsive" 
                                style={{maxHeight: '65vh', overflowY: 'auto', paddingBottom: '1rem'}}
                            >
                                <Table size="sm" className="table table-bordered table-striped mb-0">
                                    <thead className="table-light">
                                        <tr>
                                            <th style={compactCellStyle}>Sr. No.</th>
                                            <th style={compactCellStyle}>Voucher Date</th>
                                            <th style={compactCellStyle}>Cr Ledger Name</th>
                                            <th style={compactCellStyle}>Dr Ledger Name</th>
                                            <th style={compactCellStyle}>Narration</th>
                                            <th className="text-end" style={compactCellStyle}>Amount</th>
                                            <th style={compactCellStyle}>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {filteredData && filteredData.length > 0 ? (
                                            filteredData.map((item, index) => {
                                                const amount = getAmount(item);
                                                return (
                                                <tr key={item.Id ?? `${item.VoucherNo}-${index}`}>
                                                    <td style={compactCellStyle}>{index + 1}</td>
                                                    <td style={compactCellStyle}>{formatDate(item?.VoucherDate)}</td>
                                                    <td style={compactCellStyle}>{getCrLedgerName(item)}</td>
                                                    <td style={compactCellStyle}>{getDrLedgerName(item)}</td>
                                                    <td style={compactCellStyle}>{getNarration(item)}</td>
                                                    <td className="text-end" style={compactCellStyle}>{amount.toFixed(2)}</td>
                                                    <td style={compactCellStyle}>
                                                        <Button
                                                            color="link"
                                                            size="sm"
                                                            className="p-0"
                                                            onClick={() => handleEditClick(item)}
                                                            title="Edit voucher"
                                                            style={{
                                                                width: '34px',
                                                                height: '34px',
                                                                display: 'inline-flex',
                                                                alignItems: 'center',
                                                                justifyContent: 'center'
                                                            }}
                                                        >
                                                            <i className="mdi mdi-pencil" style={{ fontSize: '1.25rem' }} />
                                                        </Button>
                                                    </td>
                                                </tr>
                                                );
                                            })
                                        ) : (
                                            <tr>
                                                <td colSpan="7" className="text-center" style={compactCellStyle}>No data available</td>
                                            </tr>
                                        )}
                                    </tbody>
                                </Table>
                            </div>
                            {filteredData && filteredData.length > 0 && (
                                <div 
                                    className="d-flex align-items-center justify-content-between gap-2 flex-wrap mt-3"
                                    style={{
                                        position: 'sticky',
                                        bottom: 0,
                                        backgroundColor: '#fff',
                                        padding: '0.75rem 0.5rem',
                                        boxShadow: '0 -2px 6px rgba(0,0,0,0.08)',
                                        zIndex: 2
                                    }}
                                >
                                    <div className="fw-semibold" style={{minWidth: '120px'}}>Total</div>
                                    <div className="ms-auto text-end" style={{minWidth: '150px'}}>
                                        Amount: <strong>{totals.amount.toFixed(2)}</strong>
                                    </div>
                                </div>
                            )}
                        </CardBody>
                    </Card>
                </Col>
            </Row>
        </Container>
        <Modal isOpen={editModal.isOpen} toggle={closeEditModal} size="lg" centered>
            <ModalHeader toggle={closeEditModal}>Edit Voucher</ModalHeader>
            <ModalBody>
                {editModal.voucher && (
                    <>
                        <div className="mb-3">
                            <div style={{ fontSize: '0.9rem', color: '#555' }}>
                                Cr Ledger: <strong>{getCrLedgerName(editModal.voucher)}</strong>
                            </div>
                            <div style={{ fontSize: '0.9rem', color: '#555' }}>
                                Dr Ledger: <strong>{getDrLedgerName(editModal.voucher)}</strong>
                            </div>
                            <div style={{ fontSize: '0.9rem', color: '#555' }}>
                                Narration: <strong>{getNarration(editModal.voucher) || '-'}</strong>
                            </div>
                            <div style={{ fontSize: '0.9rem', color: '#555' }}>
                                Current Amount: <strong>{getAmount(editModal.voucher).toFixed(2)}</strong>
                            </div>
                        </div>
                        <VoucherForm
                            initialId={editModal.voucher.Id}
                            onCompleted={handleModalSuccess}
                            compact
                        />
                    </>
                )}
            </ModalBody>
            <ModalFooter>
                <Button color="secondary" onClick={closeEditModal}>
                    Close
                </Button>
            </ModalFooter>
        </Modal>
        <Modal isOpen={addModalOpen} toggle={closeAddModal} size="lg" centered>
            <ModalHeader toggle={closeAddModal}>Add Voucher</ModalHeader>
            <ModalBody>
                <VoucherForm
                    initialId={0}
                    onCompleted={handleModalSuccess}
                    compact
                />
            </ModalBody>
            <ModalFooter>
                <Button color="secondary" onClick={closeAddModal}>
                    Close
                </Button>
            </ModalFooter>
        </Modal>
    </div>
  )
}

export default VoucherList