import React, { useState, useEffect, useCallback } from "react"
import DatePicker from "react-datepicker"
import "react-datepicker/dist/react-datepicker.css"
import {
  Container,
  Row,
  Col,
  Form,
  Button,
  Table,
  Card,
  Alert,
  Dropdown,
  Modal,
  ModalHeader,
  ModalBody,
  Spinner,
} from "react-bootstrap"
import { API_WEB_URLS } from "constants/constAPI"
import { Fn_GetReport, Fn_DisplayData, Fn_FillListData } from "store/Functions"
import { useDispatch, useSelector } from "react-redux"
import { useNavigate } from "react-router-dom"
import {
  Search,
  Printer,
  X,
  LogOut,
  Calendar,
  Filter,
  Download,
} from "react-feather"
import DalaliModal from "./DalaliModal"
import LedgerReport from "./LedgerReport"
import { toast } from "react-toastify"

function NewLedgerReport() {
  const dispatch = useDispatch()
  const navigate = useNavigate()

  // Get global dates from Redux store
  const globalDates = useSelector(state => state.GlobalDates)
  
  const [fromDate, setFromDate] = useState(globalDates.fromDate)
  const [toDate, setToDate] = useState(globalDates.toDate)
  const [ItemId, setItemId] = useState(0)
  const [selectedItemIds, setSelectedItemIds] = useState([])

  const [showTable, setShowTable] = useState(false)
  const [loading, setLoading] = useState(false)
  const [showReport, setShowReport] = useState(false)
  const [selectedRows, setSelectedRows] = useState(new Set()) // Store LedgerIds instead of indices
  const [selectAll, setSelectAll] = useState(false)
  const [isSelectingAll, setIsSelectingAll] = useState(false)
  const [ledgerFilter, setLedgerFilter] = useState("")
  const [totalFilter, setTotalFilter] = useState("") // ">0", "=0", or ""
  const [showDalaliDataModal, setShowDalaliDataModal] = useState(false)
  const [selectedLedgerId, setSelectedLedgerId] = useState(null)
  const [selectedFinancialYearId, setSelectedFinancialYearId] = useState(null)
  const [financialYearArray, setFinancialYearArray] = useState([])
  const [error, setError] = useState("")

  const [state, setState] = useState({
    FillArray: [],
    ItemArray: [],

    FromDate: globalDates.fromDate,
    ToDate: globalDates.toDate,
  })

  const API_URL_Get = `${API_WEB_URLS.LedgerDalaliCalculation}/0/token`
  const API_URL = API_WEB_URLS.MASTER + "/0/token/ItemMaster"
  const API_URL_Financial = API_WEB_URLS.MASTER + "/0/token/FinancialYearMaster"

  useEffect(() => {
    Fn_FillListData(dispatch, setState, "ItemArray", API_URL + "/Id/0")
    Fn_FillListData(dispatch, setFinancialYearArray, "gridData", API_URL_Financial + "/Id/0")
  }, [dispatch])

  // Auto-load data when component mounts
  useEffect(() => {
    if (state.ItemArray.length > 0) {
      loadData()
    }
  }, [state.ItemArray])

  // Auto-load data when dates change
  useEffect(() => {
    if (state.ItemArray.length > 0) {
      loadData()
    }
  }, [fromDate, toDate])

  // Auto-load data when selected items change
  useEffect(() => {
    if (state.ItemArray.length > 0) {
      loadData()
    }
  }, [selectedItemIds])

  // Auto-show table when data is received
  useEffect(() => {
    console.log("FillArray updated:", state.FillArray)
    if (state.FillArray && state.FillArray.length > 0) {
      console.log("Setting showTable to true")
      setShowTable(true)
      setShowReport(true)
      // Reset selection state when new data is loaded
      setSelectedRows(new Set())
      setSelectAll(false)
      setIsSelectingAll(false)
    }
  }, [state.FillArray])

  // Helper function to format date in local time (YYYY-MM-DD)
  const formatDateLocal = (date) => {
    if (!date) return ""
    const year = date.getFullYear()
    const month = String(date.getMonth() + 1).padStart(2, '0')
    const day = String(date.getDate()).padStart(2, '0')
    return `${year}-${month}-${day}`
  }

  const loadData = async () => {
    setLoading(true)
    setError("")

    try {
      let vformData = new FormData()

      vformData.append("FromDate", formatDateLocal(fromDate) || "")
      vformData.append("ToDate", formatDateLocal(toDate) || "")
      vformData.append("ItemIds", selectedItemIds.join(","))

      const result = await Fn_GetReport(
        dispatch,
        setState,
        "FillArray",
        API_URL_Get,
        { arguList: { id: 0, formData: vformData } },
        true
      )

      // Show table after data is received
      setShowTable(true)
      setShowReport(true)
    } catch (error) {
      setError("Error generating report. Please try again.")
      console.error("Report generation error:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleRowDoubleClick = async () => {
    // Check if any ledgers are selected
    if (selectedRows.size === 0) {
      toast.error("Please select a party first.")
      return
    }

    // Convert selected ledger IDs to comma-separated string
    const selectedLedgerIds = Array.from(selectedRows).join(",")

    // Get ledger names for the selected IDs and convert to comma-separated string
    const selectedLedgerNames = Array.from(selectedRows)
      .map(ledgerId => {
        const row = state.FillArray.find(r => r.LedgerId === ledgerId)
        return row ? row.LedgerName : `Ledger ${ledgerId}`
      })
      .join(",")

    // Navigate to LedgerReport with the selected ledger data
    navigate("/LedgerReport", {
      state: {
        ledgerIds: selectedLedgerIds,
        ledgerNames: selectedLedgerNames,
        fromDate: fromDate,
        toDate: toDate,
        itemIds: selectedItemIds.join(","),
      },
    })
  }

 

  const handleOpenDalali = ledgerId => {
    setSelectedLedgerId(ledgerId)
    setShowDalaliDataModal(true)
  }

  // Checkbox selection handlers with performance optimization
  const handleSelectAll = useCallback(
    checked => {
      const filteredData = getFilteredAndSortedData()

      if (checked && filteredData.length > 1000) {
        // For large datasets, show loading state
        setIsSelectingAll(true)
      }

      setSelectAll(checked)

      // Use setTimeout to prevent UI blocking for large datasets
      setTimeout(() => {
        if (checked) {
          // Select all filtered rows by their LedgerId
          const filteredLedgerIds = new Set(
            filteredData.map(row => row.LedgerId)
          )
          setSelectedRows(filteredLedgerIds)
        } else {
          setSelectedRows(new Set())
        }
        setIsSelectingAll(false)
      }, 0)
    },
    [state.FillArray, ledgerFilter, totalFilter]
  )

  const handleRowSelect = useCallback(
    (ledgerId, checked) => {
      console.log("handleRowSelect called:", { ledgerId, checked })
      setSelectedRows(prevSelected => {
        const newSelectedRows = new Set(prevSelected)
        if (checked) {
          newSelectedRows.add(ledgerId)
        } else {
          newSelectedRows.delete(ledgerId)
        }

        console.log("Updated selectedRows:", Array.from(newSelectedRows))

        // Update select all state based on filtered data
        const filteredData = getFilteredAndSortedData()
        const filteredLedgerIds = filteredData.map(row => row.LedgerId)

        // Check if all filtered rows are selected
        const allFilteredSelected =
          filteredLedgerIds.length > 0 &&
          filteredLedgerIds.every(id => newSelectedRows.has(id))

        setSelectAll(allFilteredSelected)

        return newSelectedRows
      })
    },
    [state.FillArray, ledgerFilter, totalFilter]
  )

  // Filter and sort data based on ledger filter and total filter
  const getFilteredAndSortedData = () => {
    let filteredData = state.FillArray

    // Filter by ledger name if filter text is provided
    if (ledgerFilter.trim()) {
      filteredData = filteredData.filter(
        row =>
          row.LedgerName &&
          row.LedgerName.toLowerCase().includes(ledgerFilter.toLowerCase())
      )
    }

    // Filter by total value if total filter is provided
    if (totalFilter) {
      filteredData = filteredData.filter(row => {
        const total = parseFloat(row.Total) || 0
        if (totalFilter === ">0") {
          return total > 0
        } else if (totalFilter === "=0") {
          return total === 0
        }
        return true
      })
    }

    // Sort alphabetically by LedgerName
    return filteredData.sort((a, b) => {
      const nameA = (a.LedgerName || "").toLowerCase()
      const nameB = (b.LedgerName || "").toLowerCase()
      return nameA.localeCompare(nameB)
    })
  }

  // Auto-select filtered results when filter changes
  useEffect(() => {
    if ((ledgerFilter.trim() || totalFilter) && state.FillArray.length > 0) {
      const filteredData = getFilteredAndSortedData()
      const filteredLedgerIds = new Set(filteredData.map(row => row.LedgerId))

      setSelectedRows(filteredLedgerIds)
      setSelectAll(
        filteredLedgerIds.size === filteredData.length &&
          filteredData.length > 0
      )
    } else if (
      !ledgerFilter.trim() &&
      !totalFilter &&
      state.FillArray.length > 0
    ) {
      // Clear selection when filter is removed
      setSelectedRows(new Set())
      setSelectAll(false)
    }
  }, [ledgerFilter, totalFilter, state.FillArray])

  // Calculate totals for selected rows
  const calculateSelectedTotals = () => {
    if (selectedRows.size === 0) {
      return {
        totalSellerQty: 0,
        totalBuyerQty: 0,
        weightedAvgSellerRate: 0,
        weightedAvgBuyerRate: 0,
        profitLoss: 0,
        totalSum: 0,
      }
    }

    let totalSellerQty = 0
    let totalBuyerQty = 0
    let totalSellerQtyRate = 0 // Sum of (SellerQty × AvgSellerRate)
    let totalBuyerQtyRate = 0 // Sum of (BuyerQty × AvgBuyerRate)
    let totalSum = 0

    selectedRows.forEach(ledgerId => {
      const row = state.FillArray.find(r => r.LedgerId === ledgerId)
      if (row) {
        const sellerQty = parseFloat(row.TotalSellerQty) || 0
        const buyerQty = parseFloat(row.TotalBuyerQty) || 0
        const avgSellerRate = parseFloat(row.AvgSellerRate) || 0
        const avgBuyerRate = parseFloat(row.AvgBuyerRate) || 0
        const rowTotal = parseFloat(row.Total) || 0

        totalSellerQty += sellerQty
        totalBuyerQty += buyerQty
        totalSum += rowTotal

        // Calculate weighted rates: Qty × Rate
        totalSellerQtyRate += sellerQty * avgSellerRate
        totalBuyerQtyRate += buyerQty * avgBuyerRate
      }
    })

    // Calculate weighted average rates
    const weightedAvgSellerRate =
      totalSellerQty > 0 ? totalSellerQtyRate / totalSellerQty : 0
    const weightedAvgBuyerRate =
      totalBuyerQty > 0 ? totalBuyerQtyRate / totalBuyerQty : 0

    // Calculate profit/loss: (Total Seller Amount) - (Total Buyer Amount)
    const profitLoss = totalSellerQtyRate - totalBuyerQtyRate

    return {
      totalSellerQty,
      totalBuyerQty,
      weightedAvgSellerRate,
      weightedAvgBuyerRate,
      profitLoss,
      totalSum,
    }
  }

  return (
    <div
      className="contract-register-container"
      style={{
        height: "100dvh",
        overflow: "hidden",
        display: "flex",
        flexDirection: "column",
        paddingBottom: "0px",
      }}
    >
      <style>{`
        /* Make unselected checkboxes more visible with dark bold borders */
        .form-check-input:not(:checked) {
          border: 3px solid #212529 !important;
          background-color: #fff !important;
          box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2) !important;
        }
        
        .form-check-input:checked {
          border: 3px solid #0d6efd !important;
          background-color: #0d6efd !important;
          box-shadow: 0 1px 3px rgba(13, 110, 253, 0.3) !important;
        }
        
        .form-check-input:focus {
          border-color: #0d6efd !important;
          outline: 0;
          box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25), 0 1px 3px rgba(0, 0, 0, 0.2) !important;
        }
        
        .form-check-input:hover:not(:checked) {
          border-color: #000 !important;
          background-color: #f8f9fa !important;
          box-shadow: 0 2px 4px rgba(0, 0, 0, 0.3) !important;
        }
        
        .form-check-input:hover:checked {
          border-color: #0b5ed7 !important;
          background-color: #0b5ed7 !important;
          box-shadow: 0 2px 4px rgba(13, 110, 253, 0.4) !important;
        }
      `}</style>
      {/* Removed top spacer to allow full-height usage */}

      {/* Filter Form */}
      <Card className="shadow-sm border-0 mb-2">
        <Card.Header className="bg-primary text-white">
          <h5 className="mb-0">
            <Filter className="me-2" size={18} />
            New Ledger Report
          </h5>
        </Card.Header>
        <Card.Body>
          <Form>
            <Row className="mb-2 align-items-end">
              {/* Ledger Filter */}
              {showTable && state.FillArray.length > 0 && (
                <Col lg={2} md={3} sm={4} className="mb-1">
                  <Form.Label className="fw-semibold mb-1 small">
                    Ledger:
                  </Form.Label>
                  <div className="d-flex align-items-center">
                    <Form.Control
                      type="text"
                      size="sm"
                      placeholder="Type ledger name..."
                      value={ledgerFilter}
                      onChange={e => setLedgerFilter(e.target.value)}
                      className="me-1"
                      style={{ minWidth: "120px" }}
                    />
                    {ledgerFilter && (
                      <Button
                        variant="outline-secondary"
                        size="sm"
                        onClick={() => setLedgerFilter("")}
                        className="py-0"
                        title="Clear filter"
                      >
                        <X size={12} />
                      </Button>
                    )}
                  </div>
                </Col>
              )}

              <Col lg={1} md={2} sm={2} className="mb-1">
                <Form.Label className="fw-semibold mb-1">
                  <Calendar className="me-1" size={14} />
                  From
                </Form.Label>
                <DatePicker
                  selected={fromDate}
                  onChange={date => setFromDate(date)}
                  className="form-control form-control-sm"
                  dateFormat="dd/MM/yyyy"
                  placeholderText="From Date"
                  portalId="root-portal"
                  popperPlacement="bottom-start"
                />
              </Col>

              <Col lg={1} md={2} sm={2} className="mb-1">
                <Form.Label className="fw-semibold mb-1">
                  <Calendar className="me-1" size={14} />
                  To
                </Form.Label>
                <DatePicker
                  selected={toDate}
                  onChange={date => setToDate(date)}
                  className="form-control form-control-sm"
                  dateFormat="dd/MM/yyyy"
                  placeholderText="To Date"
                  portalId="root-portal"
                  popperPlacement="bottom-start"
                />
              </Col>


               


              {/* Total Filter Checkboxes */}
              {showTable && state.FillArray.length > 0 && (
                <Col lg={1} md={2} sm={2} className="mb-1">
                  <div className="d-flex align-items-center">
                    <div className="form-check me-1">
                      <input
                        type="checkbox"
                        id="total-greater-than-zero"
                        className="form-check-input"
                        checked={totalFilter === ">0"}
                        onClick={e => {
                          e.stopPropagation()
                          const isCurrentlySelected = totalFilter === ">0"
                          if (!isCurrentlySelected) {
                            setTotalFilter(">0")
                          } else {
                            setTotalFilter("")
                          }
                        }}
                      />
                      <label
                        htmlFor="total-greater-than-zero"
                        className="form-check-label small"
                      >
                        {">0"}
                      </label>
                    </div>
                    <div className="form-check">
                      <input
                        type="checkbox"
                        id="total-equals-zero"
                        className="form-check-input"
                        checked={totalFilter === "=0"}
                        onClick={e => {
                          e.stopPropagation()
                          const isCurrentlySelected = totalFilter === "=0"
                          if (!isCurrentlySelected) {
                            setTotalFilter("=0")
                          } else {
                            setTotalFilter("")
                          }
                        }}
                      />
                      <label
                        htmlFor="total-equals-zero"
                        className="form-check-label small"
                      >
                        {"=0"}
                      </label>
                    </div>
                  </div>
                </Col>
              )}

              <Col lg={2} md={3} sm={4} className="mb-1">
                <Form.Label className="fw-semibold mb-1">Item Name</Form.Label>
                <Dropdown>
                  <Dropdown.Toggle
                    variant="outline-secondary"
                    size="sm"
                    className="w-100 text-start"
                  >
                    {selectedItemIds.length === 0
                      ? "Select Items"
                      : `${selectedItemIds.length} item(s) selected`}
                  </Dropdown.Toggle>
                  <Dropdown.Menu
                    className="w-100"
                    style={{
                      maxHeight: "200px",
                      overflowY: "auto",
                      transform: "translateY(-100%)",
                      marginTop: "-5px",
                    }}
                    onClick={e => e.stopPropagation()}
                  >
                    <Dropdown.Item as="div" className="px-3 border-bottom">
                      <div className="form-check">
                        <input
                          type="checkbox"
                          id="select-all-items"
                          className="form-check-input"
                          checked={
                            selectedItemIds.length === state.ItemArray.length &&
                            state.ItemArray.length > 0
                          }
                          onClick={e => {
                            e.stopPropagation()
                            const isCurrentlySelected =
                              selectedItemIds.length ===
                                state.ItemArray.length &&
                              state.ItemArray.length > 0
                            if (!isCurrentlySelected) {
                              setSelectedItemIds(
                                state.ItemArray.map(item => item.Id)
                              )
                            } else {
                              setSelectedItemIds([])
                            }
                          }}
                        />
                        <label
                          htmlFor="select-all-items"
                          className="form-check-label fw-semibold"
                        >
                          Select All
                        </label>
                      </div>
                    </Dropdown.Item>
                    {state.ItemArray.map(Item => (
                      <Dropdown.Item key={Item.Id} as="div" className="px-3">
                        <div className="form-check">
                          <input
                            type="checkbox"
                            id={`item-${Item.Id}`}
                            className="form-check-input"
                            checked={selectedItemIds.includes(Item.Id)}
                            onClick={e => {
                              e.stopPropagation()
                              const isCurrentlySelected =
                                selectedItemIds.includes(Item.Id)
                              if (!isCurrentlySelected) {
                                setSelectedItemIds(prev => [...prev, Item.Id])
                              } else {
                                setSelectedItemIds(prev =>
                                  prev.filter(id => id !== Item.Id)
                                )
                              }
                            }}
                          />
                          <label
                            htmlFor={`item-${Item.Id}`}
                            className="form-check-label"
                          >
                            {Item.Name}
                          </label>
                        </div>
                      </Dropdown.Item>
                    ))}
                  </Dropdown.Menu>
                </Dropdown>
              </Col>

              {/* Selection Status - Compact */}
              {selectedRows.size > 0 && (
                <Col lg={2} md={3} sm={4} className="mb-1">
                  <div className="alert alert-info d-flex justify-content-between align-items-center mb-0 py-1 px-2">
                    <div className="d-flex align-items-center">
                      <span className="small me-2">
                        <strong>
                          {selectedRows.size}/
                          {getFilteredAndSortedData().length}
                        </strong>{" "}
                        rows
                        {(ledgerFilter || totalFilter) && (
                          <span className="text-muted ms-1">
                            ({state.FillArray.length})
                          </span>
                        )}
                      </span>
                      <span className="badge bg-success small">
                        ₹{calculateSelectedTotals().totalSum.toFixed(0)}
                      </span>
                    </div>
                    <Button
                      variant="outline-secondary"
                      size="sm"
                      className="py-0 px-2"
                      onClick={() => {
                        setSelectedRows(new Set())
                        setSelectAll(false)
                        setIsSelectingAll(false)
                      }}
                    >
                      Clear
                    </Button>
                  </div>
                </Col>
              )}
            </Row>
          </Form>
        </Card.Body>
      </Card>

      {/* Render DalaliModal directly */}
      <DalaliModal
        showDalaliDataModal={showDalaliDataModal}
        onHideDalaliDataModal={() => setShowDalaliDataModal(false)}
        ledgerId={selectedLedgerId}
        reportData={state.FillArray}
        fromDate={fromDate}
        toDate={toDate}
        financialYears={financialYearArray}
        selectedFinancialYearId={selectedFinancialYearId}
        onFinancialYearChange={id => setSelectedFinancialYearId(id)}
        onSaveSuccess={() => loadData()}
      />

      {/* Results Table */}
      {(showTable || (state.FillArray && state.FillArray.length > 0)) && (
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            flex: "1 1 auto",
            minHeight: 0,
            overflow: "hidden",
            marginBottom: "0px",
            paddingBottom: "0px",
          }}
        >
          {getFilteredAndSortedData().length > 0 ? (
            <div
              className="table-container"
              style={{
                flex: "1 1 auto",
                minHeight: 0,
                overflowY: "auto",
                border: "none",
                borderRadius: "0",
                marginBottom: "0",
                paddingBottom: "0",
              }}
            >
              <Table
                striped
                bordered
                hover
                size="sm"
                className="mb-0 fixed-table"
              >
                <thead
                  className="table-success text-center"
                  style={{ position: "sticky", top: 0, zIndex: 10 }}
                >
                  <tr>
                    <th>
                      <input
                        type="checkbox"
                        checked={selectAll}
                        disabled={isSelectingAll}
                        onClick={e => {
                          e.stopPropagation()
                          const newCheckedState = !selectAll
                          console.log("Select all checkbox clicked:", {
                            currentState: selectAll,
                            newState: newCheckedState,
                            filteredDataLength:
                              getFilteredAndSortedData().length,
                          })
                          handleSelectAll(newCheckedState)
                        }}
                        className="form-check-input"
                        title={isSelectingAll ? "Selecting all rows..." : ""}
                      />
                      {isSelectingAll && (
                        <div className="d-inline-block ms-2">
                          <div
                            className="spinner-border spinner-border-sm text-primary"
                            role="status"
                          >
                            <span className="visually-hidden">Loading...</span>
                          </div>
                        </div>
                      )}
                    </th>
                    <th>Ledger</th>
                    <th>Seller Qty</th>
                    <th>Buyer Qty</th>

                    <th>Dalali Rate</th>
                    <th>Total Seller Amt</th>
                    <th>Total Buyer Amt</th>
                    <th>Avg Seller Rate</th>
                    <th>Avg Buyer Rate</th>
                    <th>Total</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {getFilteredAndSortedData().map((row, i) => {
                    return (
                      <tr 
                        key={`row-${row.LedgerId}`}
                        onDoubleClick={handleRowDoubleClick}
                        style={{ cursor: 'pointer' }}
                        title="Double-click to view Ledger Report"
                      >
                        <td className="text-center">
                          <input
                            type="checkbox"
                            checked={selectedRows.has(row.LedgerId)}
                            disabled={isSelectingAll}
                            onClick={e => {
                              e.stopPropagation()
                              const isCurrentlySelected = selectedRows.has(
                                row.LedgerId
                              )
                              const newCheckedState = !isCurrentlySelected
                              console.log("Row checkbox clicked:", {
                                ledgerId: row.LedgerId,
                                currentState: isCurrentlySelected,
                                newState: newCheckedState,
                              })
                              handleRowSelect(row.LedgerId, newCheckedState)
                            }}
                            className="form-check-input"
                          />
                        </td>
                        <td
                          className="text-nowrap fw-semibold text-truncate"
                          title={row.LedgerName}
                        >
                          {row.LedgerName}
                        </td>

                        <td
                          className="text-nowrap text-truncate"
                          title={row.SellerQty}
                        >
                          {row.TotalSellerQty}
                        </td>
                        <td
                          className="text-nowrap text-truncate"
                          title={row.BuyerQty}
                        >
                          {row.TotalBuyerQty}
                        </td>

                        <td
                          className="text-nowrap text-truncate"
                          title={row.DalaliRate}
                        >
                          {row.DalaliRate}
                        </td>
                        <td
                          className="text-nowrap text-truncate"
                          title={row.TotalSellerAmount}
                        >
                          {row.TotalSellerAmount}
                        </td>
                        <td
                          className="text-nowrap text-truncate"
                          title={row.TotalBuyerAmount}
                        >
                          {row.TotalBuyerAmount}
                        </td>
                        <td
                          className="text-nowrap text-truncate"
                          title={row.AvgSellerRate}
                        >
                          {row.AvgSellerRate}
                        </td>
                        <td
                          className="text-nowrap text-truncate"
                          title={row.AvgBuyerRate}
                        >
                          {row.AvgBuyerRate}
                        </td>
                        <td
                          className="text-nowrap text-truncate"
                          title={row.Total}
                        >
                          {row.Total}
                        </td>
                        <td
                          className="text-nowrap text-truncate"
                          title={row.Action}
                        >
                          <Button
                            variant="primary"
                            size="sm"
                            onClick={() => handleOpenDalali(row.LedgerId)}
                          >
                            Open Dalali
                          </Button>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </Table>

              {/* Fixed Footer with Totals */}
              {selectedRows.size > 0 && (
                <div
                  className="table-footer-totals"
                  style={{
                    position: "fixed",
                    bottom: "0",
                    left: "0",
                    right: "0",
                    width: "100%",
                    backgroundColor: "#000000",
                    zIndex: 1000,
                    padding: "5px 10px",
                    margin: "0",
                    borderTop: "2px solid #fff",
                  }}
                >
                  <Row className="align-items-center" style={{ margin: "0" }}>
                    <Col md={12}>
                      <div className="d-flex align-items-center flex-wrap">
                        <span className="fw-semibold me-3 text-white">
                          Selected Totals:
                        </span>
                        <span className="badge bg-primary me-2 fs-6">
                          Sel Qty:{" "}
                          {calculateSelectedTotals().totalSellerQty.toFixed(2)}
                        </span>
                        <span className="badge bg-danger me-2 fs-6">
                          Buy Qty:{" "}
                          {calculateSelectedTotals().totalBuyerQty.toFixed(2)}
                        </span>
                        <span className="badge bg-info me-2 fs-6">
                          Avg Sel Rate:{" "}
                          {calculateSelectedTotals().weightedAvgSellerRate.toFixed(
                            2
                          )}
                        </span>
                        <span className="badge bg-warning me-2 fs-6">
                          Avg Buy Rate:{" "}
                          {calculateSelectedTotals().weightedAvgBuyerRate.toFixed(
                            2
                          )}
                        </span>
                        <span
                          className={`badge fs-6 ${
                            calculateSelectedTotals().profitLoss >= 0
                              ? "bg-success"
                              : "bg-danger"
                          }`}
                        >
                          {calculateSelectedTotals().profitLoss >= 0
                            ? "Profit"
                            : "Loss"}
                          :{" "}
                          {Math.abs(
                            calculateSelectedTotals().profitLoss
                          ).toFixed(2)}
                        </span>
                      </div>
                    </Col>
                    <Col md={4} className="text-end">
                      <small className="text-light">
                        {ledgerFilter || totalFilter ? (
                          <>
                            {selectedRows.size} filtered rows selected
                            <span className="d-block">
                              (from {getFilteredAndSortedData().length}{" "}
                              filtered, {state.FillArray.length} total)
                            </span>
                          </>
                        ) : (
                          `${selectedRows.size} of ${state.FillArray.length} rows selected`
                        )}
                      </small>
                    </Col>
                  </Row>
                </div>
              )}
            </div>
          ) : (
            <div className="text-center p-5">
              <div className="text-muted">
                <Search size={48} className="mb-3" />
                <h5>No Data Found</h5>
                <p>
                  {ledgerFilter || totalFilter
                    ? `No ledgers found matching the current filters. Please try adjusting your filters.`
                    : "No records match the selected criteria. Please try adjusting your filters."}
                </p>
                {(ledgerFilter || totalFilter) && (
                  <Button
                    variant="outline-secondary"
                    size="sm"
                    onClick={() => {
                      setLedgerFilter("")
                      setTotalFilter("")
                    }}
                  >
                    Clear Filters
                  </Button>
                )}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Loading State */}
      {loading && (
        <div className="text-center p-5">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
          <p className="mt-2 text-muted">Generating report, please wait...</p>
        </div>
      )}
    </div>
  )
}

export default NewLedgerReport
