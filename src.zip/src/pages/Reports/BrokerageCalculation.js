import { API_WEB_URLS } from 'constants/constAPI';
import React, { useEffect, useMemo, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { Fn_GetReport } from 'store/Functions';
import { Card, CardBody, Col, Container, Row, Table, Input } from 'reactstrap';

function BrokerageCalculation() {
    const dispatch = useDispatch();
    const globalDates = useSelector(state => state.GlobalDates);
    const [state, setState] = useState({
        FillArray: [],
        LedgerArray: [],
        FromDate: globalDates.fromDate,
        ToDate: globalDates.toDate,   
    });
    const [searchTerm, setSearchTerm] = useState('');
    const compactCellStyle = { padding: '0.35rem 0.5rem', fontSize: '0.85rem' };

    const API_URL_Get = `${API_WEB_URLS.BrokerageCalculation}/0/token`
    
const getBrokerageCalculation = async () => {
    try {
        const formData = new FormData();
        const fromDate = new Date(state.FromDate).toISOString().split('T')[0];
        const toDate = new Date(state.ToDate).toISOString().split('T')[0];
        formData.append("FromDate", fromDate);
        formData.append("ToDate", toDate);
        const response = await Fn_GetReport(dispatch, setState, "FillArray", API_URL_Get, { arguList: { id: 0, formData: formData } }, true);
   
    } catch (error) {
        console.log("error", error);
    }
}

    const handleDateChange = (field, value) => {
        setState(prev => ({
            ...prev,
            [field]: value
        }));
    }

    const filteredData = (state.FillArray ?? []).filter(item => 
        (item?.LedgerName ?? '').toLowerCase().includes(searchTerm.toLowerCase())
    );

    const totals = useMemo(() => {
        const initialTotals = {
            sellerQty: 0,
            buyerQty: 0,
            brokerage: 0,
            crAmount: 0,
            drAmount: 0,
            balance: 0
        };

        return filteredData.reduce((sum, item) => ({
            sellerQty: sum.sellerQty + item.TotalSellerQty,
            buyerQty: sum.buyerQty + item.TotalBuyerQty,
            brokerage: sum.brokerage + item.TotalBrokerage,
            crAmount: sum.crAmount + item.CrAmountTotal,
            drAmount: sum.drAmount + item.DrAmountTotal,
            balance: sum.balance + item.LedgerBalance
        }), initialTotals);
    }, [filteredData]);

    useEffect(() => {
        getBrokerageCalculation();
    }, [dispatch, state.FromDate, state.ToDate])
  return (
    <div >
        <div style={{height:'2rem'}}>

        </div>
        <Container fluid>
            <Row>
                <Col lg={12}>
                    <Card>
                        <CardBody>
                            <div className="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
                                <h4 className="card-title mb-0">Brokerage Register</h4>
                                <div className="d-flex align-items-center gap-2 flex-wrap">
                                    <div className="d-flex align-items-center gap-1">
                                        <label className="mb-0" style={{fontSize: '0.875rem', whiteSpace: 'nowrap'}}>From:</label>
                                        <Input
                                            type="date"
                                            value={state.FromDate ? new Date(state.FromDate).toISOString().split('T')[0] : ''}
                                            onChange={(e) => handleDateChange('FromDate', e.target.value)}
                                            style={{width: '140px', fontSize: '0.875rem', padding: '0.25rem 0.5rem'}}
                                        />
                                    </div>
                                    <div className="d-flex align-items-center gap-1">
                                        <label className="mb-0" style={{fontSize: '0.875rem', whiteSpace: 'nowrap'}}>To:</label>
                                        <Input
                                            type="date"
                                            value={state.ToDate ? new Date(state.ToDate).toISOString().split('T')[0] : ''}
                                            onChange={(e) => handleDateChange('ToDate', e.target.value)}
                                            style={{width: '140px', fontSize: '0.875rem', padding: '0.25rem 0.5rem'}}
                                        />
                                    </div>
                                    <Input
                                        type="text"
                                        placeholder="Search Ledger..."
                                        value={searchTerm}
                                        onChange={(e) => setSearchTerm(e.target.value)}
                                        style={{width: '180px', fontSize: '0.875rem', padding: '0.25rem 0.5rem'}}
                                    />
                                </div>
                            </div>
                            <div 
                                className="table-responsive" 
                                style={{maxHeight: '65vh', overflowY: 'auto', paddingBottom: '1rem'}}
                            >
                                <Table size="sm" className="table table-bordered table-striped mb-0">
                                    <thead className="table-light">
                                        <tr>
                                            <th style={compactCellStyle}>Sr. No.</th>
                                            <th style={compactCellStyle}>Ledger Name</th>
                                            <th className="text-end" style={compactCellStyle}>Sell Qty</th>
                                            <th className="text-end" style={compactCellStyle}>Pur Qty</th>
                                            <th className="text-end" style={compactCellStyle}>Total Brokerage</th>
                                            <th className="text-end" style={compactCellStyle}>Cr Amount</th>
                                            <th className="text-end" style={compactCellStyle}>Dr Amount</th>
                                            <th className="text-end" style={compactCellStyle}>Balance</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {filteredData && filteredData.length > 0 ? (
                                            filteredData.map((item, index) => (
                                                <tr key={item.LedgerId}>
                                                    <td style={compactCellStyle}>{index + 1}</td>
                                                    <td style={compactCellStyle}>{item.LedgerName}</td>
                                                    <td className="text-end" style={compactCellStyle}>{item.TotalSellerQty.toFixed(2)}</td>
                                                    <td className="text-end" style={compactCellStyle}>{item.TotalBuyerQty.toFixed(2)}</td>
                                                    <td className="text-end" style={compactCellStyle}>{item.TotalBrokerage.toFixed(2)}</td>
                                                    <td className="text-end" style={compactCellStyle}>{item.CrAmountTotal.toFixed(2)}</td>
                                                    <td className="text-end" style={compactCellStyle}>{item.DrAmountTotal.toFixed(2)}</td>
                                                    <td className="text-end" style={compactCellStyle}>{item.LedgerBalance.toFixed(2)}</td>
                                                </tr>
                                            ))
                                        ) : (
                                            <tr>
                                                <td colSpan="8" className="text-center" style={compactCellStyle}>No data available</td>
                                            </tr>
                                        )}
                                    </tbody>
                                </Table>
                            </div>
                            {filteredData && filteredData.length > 0 && (
                                <div 
                                    className="d-flex align-items-center justify-content-between gap-2 flex-wrap mt-3"
                                    style={{
                                        position: 'sticky',
                                        bottom: 0,
                                        backgroundColor: '#fff',
                                        padding: '0.75rem 0.5rem',
                                        boxShadow: '0 -2px 6px rgba(0,0,0,0.08)',
                                        zIndex: 2
                                    }}
                                >
                                    <div className="fw-semibold" style={{minWidth: '120px'}}>Total</div>
                                    <div className="ms-auto text-end" style={{minWidth: '120px'}}>
                                        Sell Qty: <strong>{totals.sellerQty.toFixed(2)}</strong>
                                    </div>
                                    <div className="text-end" style={{minWidth: '120px'}}>
                                        Pur Qty: <strong>{totals.buyerQty.toFixed(2)}</strong>
                                    </div>
                                    <div className="text-end" style={{minWidth: '150px'}}>
                                        Brokerage: <strong>{totals.brokerage.toFixed(2)}</strong>
                                    </div>
                                    <div className="text-end" style={{minWidth: '120px'}}>
                                        Cr Amount: <strong>{totals.crAmount.toFixed(2)}</strong>
                                    </div>
                                    <div className="text-end" style={{minWidth: '120px'}}>
                                        Dr Amount: <strong>{totals.drAmount.toFixed(2)}</strong>
                                    </div>
                                    <div className="text-end" style={{minWidth: '150px'}}>
                                        Balance: <strong>{totals.balance.toFixed(2)}</strong>
                                    </div>
                                </div>
                            )}
                        </CardBody>
                    </Card>
                </Col>
            </Row>
        </Container>
    </div>
  )
}

export default BrokerageCalculation