import PropTypes from "prop-types";
import React, { useState, useEffect } from "react";
import {
  Container, Row, Col, Card, CardBody, Button, Spinner, Badge
} from "reactstrap";
import { Eye, EyeOff, Copy, FileText, Calendar } from 'react-feather';
import { useNavigate } from 'react-router-dom';

//Import Breadcrumb
import Breadcrumbs from "../../components/Common/Breadcrumb";

//i18n
import { withTranslation } from "react-i18next";
import { Fn_FillListData, Fn_GetReport } from "store/Functions";
import { useDispatch, useSelector } from "react-redux";
import { setGlobalDates } from "store/common-actions";

 
const Dashboard = props => {
  //meta title
  document.title = "Dashboard | Shinewell SoftTech";
  const navigate = useNavigate();
  const dispatch = useDispatch();

  // Get global dates from Redux store
  const globalDates = useSelector(state => state.GlobalDates);
  
  // Local state for date inputs
  const [fromDate, setFromDate] = useState(globalDates.fromDate);
  const [toDate, setToDate] = useState(globalDates.toDate);

  // Helper function to format date as YYYY-MM-DD without timezone conversion
  const formatDateForInput = (date) => {
    if (!date) return ''
    const d = new Date(date)
    const year = d.getFullYear()
    const month = String(d.getMonth() + 1).padStart(2, '0')
    const day = String(d.getDate()).padStart(2, '0')
    return `${year}-${month}-${day}`
  }

  // Update global dates when local dates change
  const handleDateChange = (newFromDate, newToDate) => {
    dispatch(setGlobalDates(newFromDate, newToDate));
  };

  // Sync local state with global dates on mount and when global dates change
  useEffect(() => {
    setFromDate(new Date(globalDates.fromDate));
    setToDate(new Date(globalDates.toDate));
  }, [globalDates.fromDate, globalDates.toDate]);

  // Add keyboard event listener for Ctrl+C and Ctrl+G
  useEffect(() => {
    const handleKeyDown = (event) => {
      if (event.ctrlKey && event.key === 'c') {
        event.preventDefault();
        navigate('/Contract');
      }
      if (event.ctrlKey && event.key === 'g') {
        event.preventDefault();
        navigate('/UpdateGlobalOptions');
      }
      if (event.ctrlKey && event.key === 'l') {
        event.preventDefault();
        navigate('/LedgerMaster');
      }
      if (event.ctrlKey && event.key === 'm') {
        event.preventDefault();
        navigate('/TransportMaster');
      }
      if (event.ctrlKey && event.key === 'i') {
        event.preventDefault();
        navigate('/ItemMaster');
      }
      if (event.ctrlKey && event.key === 'u') {
        event.preventDefault();
        navigate('/UnitMaster');
      }
      if (event.ctrlKey && event.key === 'd') {
        event.preventDefault();
        navigate('/DalaliReport');
      }
      if (event.ctrlKey && event.key === 'r') {
        event.preventDefault();
        navigate('/ContractRegister');
      }
      if (event.ctrlKey && event.key === 'a') {
        event.preventDefault();
        navigate('/NewLedgerReport');
      }
      if (event.ctrlKey && event.key === 'p') {
        event.preventDefault();
        navigate('/MultiPrint');
      }
      
    };

    document.addEventListener('keydown', handleKeyDown);
    
    // Cleanup event listener
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [navigate]);

   
  return (
    <React.Fragment>
      <div >
        <Container fluid>
          {/* Render Breadcrumb */}
          <Breadcrumbs
            title={props.t("Dashboards")}
            breadcrumbItem={props.t("Dashboard")}
          />

          {/* Global Date Range Section */}
          <Row className="mb-3">
            <Col lg={12}>
              <Card className="border-0 shadow-sm" style={{backgroundColor: '#e3f2fd'}}>
                <CardBody className="p-3">
                  <Row className="align-items-center">
                    <Col xs="auto">
                      <div className="d-flex align-items-center">
                        <Calendar className="text-primary me-2" size={20} />
                        <h6 className="mb-0 fw-bold">Global Date Range</h6>
                      </div>
                    </Col>
                    <Col xs="auto">
                      <div className="d-flex align-items-center gap-2">
                        <label className="mb-0 fw-semibold small text-muted">From:</label>
                        <input
                          type="date"
                          value={formatDateForInput(fromDate)}
                          onChange={e => {
                            if (e.target.value) {
                              const newDate = new Date(e.target.value + 'T00:00:00')
                              setFromDate(newDate)
                              handleDateChange(newDate, toDate)
                            }
                          }}
                          className="form-control form-control-sm"
                          style={{
                            width: '140px',
                            fontSize: '0.85rem'
                          }}
                        />
                      </div>
                    </Col>
                    <Col xs="auto">
                      <div className="d-flex align-items-center gap-2">
                        <label className="mb-0 fw-semibold small text-muted">To:</label>
                        <input
                          type="date"
                          value={formatDateForInput(toDate)}
                          onChange={e => {
                            if (e.target.value) {
                              const newDate = new Date(e.target.value + 'T00:00:00')
                              setToDate(newDate)
                              handleDateChange(fromDate, newDate)
                            }
                          }}
                          className="form-control form-control-sm"
                          style={{
                            width: '140px',
                            fontSize: '0.85rem'
                          }}
                        />
                      </div>
                    </Col>
                    <Col xs="auto">
                      <Badge color="info" className="py-2 px-3">
                        <i className="fas fa-info-circle me-1"></i>
                        These dates will be used in all reports
                      </Badge>
                    </Col>
                  </Row>
                </CardBody>
              </Card>
            </Col>
          </Row>

          <Row className="mb-4">
            {/* Left Container - Keyboard Shortcuts */}
            <Col lg={2} md={6} className="mb-4">
              <Card className="border-0 shadow-sm h-100" style= {{backgroundColor: '#fff9c4'}}>
                <CardBody className="p-2">
                  <div className="d-flex align-items-center mb-2">
                    <Copy className="text-primary me-2" size={16} />
                    <h6 className="mb-0 fw-bold small">Quick Navigation</h6>
                  </div>
                  
                  <div 
                    className="shortcut-item p-1 bg-light rounded mb-1" 
                    style={{ cursor: 'pointer', transition: 'all 0.2s ease' }}
                    onClick={() => navigate('/Contract')}
                    onMouseEnter={(e) => {
                      e.target.closest('.shortcut-item').style.backgroundColor = '#e9ecef';
                      e.target.closest('.shortcut-item').style.transform = 'translateY(-1px)';
                    }}
                    onMouseLeave={(e) => {
                      e.target.closest('.shortcut-item').style.backgroundColor = '#f8f9fa';
                      e.target.closest('.shortcut-item').style.transform = 'translateY(0)';
                    }}
                  >
                    <div className="d-flex align-items-center justify-content-between">
                      <div>
                        <span className="fw-semibold text-dark small">Contract Page</span>
                      </div>
                      <div className="text-end">
                        <kbd className="bg-dark text-white px-1 py-0 rounded small">
                          Ctrl + C
                        </kbd>
                      </div>
                    </div>
                  </div>

                  <div 
                    className="shortcut-item p-1 bg-light rounded mb-1" 
                    style={{ cursor: 'pointer', transition: 'all 0.2s ease' }}
                    onClick={() => navigate('/UpdateGlobalOptions')}
                    onMouseEnter={(e) => {
                      e.target.closest('.shortcut-item').style.backgroundColor = '#e9ecef';
                      e.target.closest('.shortcut-item').style.transform = 'translateY(-1px)';
                    }}
                    onMouseLeave={(e) => {
                      e.target.closest('.shortcut-item').style.backgroundColor = '#f8f9fa';
                      e.target.closest('.shortcut-item').style.transform = 'translateY(0)';
                    }}
                  >
                    <div className="d-flex align-items-center justify-content-between">
                      <div>
                        <span className="fw-semibold text-dark small">Global Options</span>
                      </div>
                      <div className="text-end">
                        <kbd className="bg-dark text-white px-1 py-0 rounded small">
                          Ctrl + G
                        </kbd>
                      </div>
                    </div>
                  </div>

                  <div 
                    className="shortcut-item p-1 bg-light rounded mb-1" 
                    style={{ cursor: 'pointer', transition: 'all 0.2s ease' }}
                    onClick={() => navigate('/LedgerMaster')}
                    onMouseEnter={(e) => {
                      e.target.closest('.shortcut-item').style.backgroundColor = '#e9ecef';
                      e.target.closest('.shortcut-item').style.transform = 'translateY(-1px)';
                    }}
                    onMouseLeave={(e) => {
                      e.target.closest('.shortcut-item').style.backgroundColor = '#f8f9fa';
                      e.target.closest('.shortcut-item').style.transform = 'translateY(0)';
                    }}
                  >
                    <div className="d-flex align-items-center justify-content-between">
                      <div>
                        <span className="fw-semibold text-dark small">Ledger Master</span>
                      </div>
                      <div className="text-end">
                        <kbd className="bg-dark text-white px-1 py-0 rounded small">
                          Ctrl + L
                        </kbd>
                      </div>
                    </div>
                  </div>

                  <div 
                    className="shortcut-item p-1 bg-light rounded mb-1" 
                    style={{ cursor: 'pointer', transition: 'all 0.2s ease' }}
                    onClick={() => navigate('/TransportMaster')}
                    onMouseEnter={(e) => {
                      e.target.closest('.shortcut-item').style.backgroundColor = '#e9ecef';
                      e.target.closest('.shortcut-item').style.transform = 'translateY(-1px)';
                    }}
                    onMouseLeave={(e) => {
                      e.target.closest('.shortcut-item').style.backgroundColor = '#f8f9fa';
                      e.target.closest('.shortcut-item').style.transform = 'translateY(0)';
                    }}
                  >
                    <div className="d-flex align-items-center justify-content-between">
                      <div>
                        <span className="fw-semibold text-dark small">Transport Master</span>
                      </div>
                      <div className="text-end">
                        <kbd className="bg-dark text-white px-1 py-0 rounded small">
                          Ctrl + M
                        </kbd>
                      </div>
                    </div>
                  </div>

                  <div 
                    className="shortcut-item p-1 bg-light rounded mb-1" 
                    style={{ cursor: 'pointer', transition: 'all 0.2s ease' }}
                    onClick={() => navigate('/ItemMaster')}
                    onMouseEnter={(e) => {
                      e.target.closest('.shortcut-item').style.backgroundColor = '#e9ecef';
                      e.target.closest('.shortcut-item').style.transform = 'translateY(-1px)';
                    }}
                    onMouseLeave={(e) => {
                      e.target.closest('.shortcut-item').style.backgroundColor = '#f8f9fa';
                      e.target.closest('.shortcut-item').style.transform = 'translateY(0)';
                    }}
                  >
                    <div className="d-flex align-items-center justify-content-between">
                      <div>
                        <span className="fw-semibold text-dark small">Item Master</span>
                      </div>
                      <div className="text-end">
                        <kbd className="bg-dark text-white px-1 py-0 rounded small">
                          Ctrl + I
                        </kbd>
                      </div>
                    </div>
                  </div>

                  <div 
                    className="shortcut-item p-1 bg-light rounded mb-1" 
                    style={{ cursor: 'pointer', transition: 'all 0.2s ease' }}
                    onClick={() => navigate('/UnitMaster')}
                    onMouseEnter={(e) => {
                      e.target.closest('.shortcut-item').style.backgroundColor = '#e9ecef';
                      e.target.closest('.shortcut-item').style.transform = 'translateY(-1px)';
                    }}
                    onMouseLeave={(e) => {
                      e.target.closest('.shortcut-item').style.backgroundColor = '#f8f9fa';
                      e.target.closest('.shortcut-item').style.transform = 'translateY(0)';
                    }}
                  >
                    <div className="d-flex align-items-center justify-content-between">
                      <div>
                        <span className="fw-semibold text-dark small">Unit Master</span>
                      </div>
                      <div className="text-end">
                        <kbd className="bg-dark text-white px-1 py-0 rounded small">
                          Ctrl + U
                        </kbd>
                      </div>
                    </div>
                  </div>


                  <div 
                    className="shortcut-item p-1 bg-light rounded mb-1" 
                    style={{ cursor: 'pointer', transition: 'all 0.2s ease' }}
                    onClick={() => navigate('/DalaliReport')}
                    onMouseEnter={(e) => {
                      e.target.closest('.shortcut-item').style.backgroundColor = '#e9ecef';
                      e.target.closest('.shortcut-item').style.transform = 'translateY(-1px)';
                    }}
                    onMouseLeave={(e) => {
                      e.target.closest('.shortcut-item').style.backgroundColor = '#f8f9fa';
                      e.target.closest('.shortcut-item').style.transform = 'translateY(0)';
                    }}
                  >
                    <div className="d-flex align-items-center justify-content-between">
                      <div>
                        <span className="fw-semibold text-dark small">Dalali Report</span>
                      </div>
                      <div className="text-end">
                        <kbd className="bg-dark text-white px-1 py-0 rounded small">
                          Ctrl + D
                        </kbd>
                      </div>
                    </div>
                  </div>

                  <div 
                    className="shortcut-item p-1 bg-light rounded mb-1" 
                    style={{ cursor: 'pointer', transition: 'all 0.2s ease' }}
                    onClick={() => navigate('/ContractRegister')}
                    onMouseEnter={(e) => {
                      e.target.closest('.shortcut-item').style.backgroundColor = '#e9ecef';
                      e.target.closest('.shortcut-item').style.transform = 'translateY(-1px)';
                    }}
                    onMouseLeave={(e) => {
                      e.target.closest('.shortcut-item').style.backgroundColor = '#f8f9fa';
                      e.target.closest('.shortcut-item').style.transform = 'translateY(0)';
                    }}
                  >
                    <div className="d-flex align-items-center justify-content-between">
                      <div>
                        <span className="fw-semibold text-dark small">Contract Register</span>
                      </div>
                      <div className="text-end">
                        <kbd className="bg-dark text-white px-1 py-0 rounded small">
                          Ctrl + R
                        </kbd>
                      </div>
                    </div>
                  </div>

                  <div 
                    className="shortcut-item p-1 bg-light rounded mb-1" 
                    style={{ cursor: 'pointer', transition: 'all 0.2s ease' }}
                    onClick={() => navigate('/NewLedgerReport')}
                    onMouseEnter={(e) => {
                      e.target.closest('.shortcut-item').style.backgroundColor = '#e9ecef';
                      e.target.closest('.shortcut-item').style.transform = 'translateY(-1px)';
                    }}
                    onMouseLeave={(e) => {
                      e.target.closest('.shortcut-item').style.backgroundColor = '#f8f9fa';
                      e.target.closest('.shortcut-item').style.transform = 'translateY(0)';
                    }}
                  >
                    <div className="d-flex align-items-center justify-content-between">
                      <div>
                        <span className="fw-semibold text-dark small">Ledger List</span>
                      </div>
                      <div className="text-end">
                        <kbd className="bg-dark text-white px-1 py-0 rounded small">
                          Ctrl + A
                        </kbd>
                      </div>
                    </div>
                  </div>

                  
                  <div 
                    className="shortcut-item p-1 bg-light rounded mb-1" 
                    style={{ cursor: 'pointer', transition: 'all 0.2s ease' }}
                    onClick={() => navigate('/MultiPrint')}
                    onMouseEnter={(e) => {
                      e.target.closest('.shortcut-item').style.backgroundColor = '#e9ecef';
                      e.target.closest('.shortcut-item').style.transform = 'translateY(-1px)';
                    }}
                    onMouseLeave={(e) => {
                      e.target.closest('.shortcut-item').style.backgroundColor = '#f8f9fa';
                      e.target.closest('.shortcut-item').style.transform = 'translateY(0)';
                    }}
                  >
                    <div className="d-flex align-items-center justify-content-between">
                      <div>
                        <span className="fw-semibold text-dark small">Multi Print</span>
                      </div>
                      <div className="text-end">
                        <kbd className="bg-dark text-white px-1 py-0 rounded small">
                          Ctrl + P
                        </kbd>
                      </div>
                    </div>
                  </div>
                  
                </CardBody>
              </Card>
            </Col>

            {/* Right Container - Welcome Section with ShreeRam Image */}
            <Col lg={8} md={6}  >
              <Card className="border-0 shadow-sm" style= {{backgroundColor: '#fff9c4'}}>
                <CardBody className="text-center p-5" style= {{backgroundColor: '#fff9c4'}}>
                  <div className="mb-4">
                    <img 
                      src={require("../../assets/images/contract/ShreeRam.jpeg")} 
                      alt="Shri Ram" 
                      className="img-fluid rounded-circle shadow"
                      style={{ 
                        width: '200px', 
                        height: '200px', 
                        objectFit: 'cover',
                        border: '4px solid #f8f9fa'
                      }}
                    />
                  </div>
                  <h2 className="text-primary mb-3 fw-bold">
                    Welcome to Shri Ram Agri Broker
                  </h2>
                  <p className="text-muted fs-5 mb-0">
                    Your trusted partner in agricultural brokerage services
                  </p>
                </CardBody>
              </Card>
            </Col>
          </Row>
           
        </Container>
      </div>
    </React.Fragment>
  );
};

Dashboard.propTypes = {
  t: PropTypes.any,
};

export default withTranslation()(Dashboard);
